"""
MCP server over two parquet files stored in Azure, served from DuckDB.

Data layout
-----------
p1    parquet 1 as-is: (A joined with B). A's columns are repeated on every B row.
p2    parquet 2 as-is: table C (rarely used, many rows per key).
a_dim DISTINCT (key + A columns) taken from p1, so exactly one row per key.
      Built once at startup. It is NOT a copy of the whole 400k-row table.

Rules
-----
* Parquet-1 tools query p1 only. They never touch p2 or a_dim.
* Parquet-2 tools query p2. If (and only if) the question needs A columns,
  the server LEFT JOINs p2 to a_dim on the key. Because a_dim is unique per key,
  the join cannot multiply p2 rows.
* The model never writes SQL. Columns come from allow-lists, values are bound
  as parameters.

Config (environment variables)
------------------------------
P1_URI, P2_URI                  az://container/path/file.parquet  (or a local path for testing)
AZURE_STORAGE_CONNECTION_STRING  or  AZURE_STORAGE_ACCOUNT (uses Azure credential chain)
KEY_COLUMN                      join key shared by all tables
A_COLUMNS                       comma-separated columns that belong to table A
MAX_ROWS                        row cap per tool call (default 500)
MCP_TRANSPORT                   stdio (default) | streamable-http
"""
import json
import logging
import os
import sys

import duckdb

try:  # mcp >= 2.0 renamed FastMCP to MCPServer
    from mcp.server.mcpserver import MCPServer as FastMCP
except ImportError:  # mcp 1.x
    from mcp.server.fastmcp import FastMCP

# stdio transport uses stdout for protocol messages: log to stderr only.
logging.basicConfig(stream=sys.stderr, level=logging.INFO)
log = logging.getLogger("parquet-mcp")

# ----------------------------------------------------------------------------
# Config
# ----------------------------------------------------------------------------
P1_URI = os.environ["P1_URI"]
P2_URI = os.environ["P2_URI"]
KEY = os.getenv("KEY_COLUMN", "account_id")
A_COLUMNS = [
    c.strip()
    for c in os.getenv("A_COLUMNS", "account_name,region,segment,account_status").split(",")
    if c.strip()
]
MAX_ROWS = int(os.getenv("MAX_ROWS", "500"))


def q(ident: str) -> str:
    """Quote an identifier. Only ever called on names already validated against an allow-list."""
    return '"' + ident.replace('"', '""') + '"'


def lit(s: str) -> str:
    return "'" + s.replace("'", "''") + "'"


# ----------------------------------------------------------------------------
# Load data
# ----------------------------------------------------------------------------
def _setup_azure(con: duckdb.DuckDBPyConnection) -> None:
    if not any(u.startswith(("az://", "azure://", "abfss://", "abfs://")) for u in (P1_URI, P2_URI)):
        return  # local files, nothing to configure
    con.execute("INSTALL azure; LOAD azure;")
    conn_str = os.getenv("AZURE_STORAGE_CONNECTION_STRING")
    if conn_str:
        con.execute(f"CREATE OR REPLACE SECRET az_secret (TYPE azure, CONNECTION_STRING {lit(conn_str)})")
    else:
        account = os.environ["AZURE_STORAGE_ACCOUNT"]
        con.execute(
            "CREATE OR REPLACE SECRET az_secret "
            f"(TYPE azure, PROVIDER credential_chain, ACCOUNT_NAME {lit(account)})"
        )


def _columns(con, table: str) -> list[str]:
    return [r[0] for r in con.execute(f"DESCRIBE {table}").fetchall()]


def build_database() -> duckdb.DuckDBPyConnection:
    con = duckdb.connect(os.getenv("DUCKDB_PATH", ":memory:"))
    _setup_azure(con)

    con.execute("CREATE OR REPLACE TABLE p1 AS SELECT * FROM read_parquet(?)", [P1_URI])
    con.execute("CREATE OR REPLACE TABLE p2 AS SELECT * FROM read_parquet(?)", [P2_URI])

    p1_cols, p2_cols = _columns(con, "p1"), _columns(con, "p2")
    for name, cols in (("p1", p1_cols), ("p2", p2_cols)):
        if KEY not in cols:
            raise RuntimeError(f"Key column {KEY!r} not found in {name}: {cols}")
    missing = [c for c in A_COLUMNS if c not in p1_cols]
    if missing:
        raise RuntimeError(f"A_COLUMNS not found in parquet 1: {missing}")

    # One row per key: take the distinct A attributes out of the duplicated parquet 1.
    select_list = ", ".join(q(c) for c in [KEY] + A_COLUMNS)
    con.execute(
        f"CREATE OR REPLACE TABLE a_dim AS SELECT DISTINCT {select_list} FROM p1 WHERE {q(KEY)} IS NOT NULL"
    )

    # Safety check: the join is only fan-out-free if a_dim is really unique per key.
    # If A's attributes differ between rows of the same key, parquet 1 is inconsistent.
    total, uniq = con.execute(f"SELECT count(*), count(DISTINCT {q(KEY)}) FROM a_dim").fetchone()
    if total != uniq:
        bad = con.execute(
            f"SELECT {q(KEY)} FROM a_dim GROUP BY 1 HAVING count(*) > 1 LIMIT 5"
        ).fetchall()
        raise RuntimeError(
            f"a_dim is not unique per {KEY}: {total} rows vs {uniq} keys. "
            f"A_COLUMNS probably contains a column that belongs to table B. Example keys: {[b[0] for b in bad]}"
        )

    n1, n2 = con.execute("SELECT (SELECT count(*) FROM p1), (SELECT count(*) FROM p2)").fetchone()
    log.info("Loaded p1=%s rows, p2=%s rows, a_dim=%s rows", n1, n2, total)
    return con


CON = build_database()
P1_COLS = _columns(CON, "p1")
P2_COLS = _columns(CON, "p2")
# Name a model sees for each A column. If p2 already has a column with that name,
# expose the A version as "a_<name>" so nothing is ambiguous.
A_EXPOSED = {(c if c not in P2_COLS else f"a_{c}"): c for c in A_COLUMNS}


# ----------------------------------------------------------------------------
# Helpers
# ----------------------------------------------------------------------------
def run(sql: str, params: list | None = None) -> list[dict]:
    cur = CON.cursor()  # cursor per call, safe with concurrent requests
    cur.execute(sql, params or [])
    names = [d[0] for d in cur.description]
    rows = cur.fetchall()
    # default=str makes dates / decimals JSON-safe
    return json.loads(json.dumps([dict(zip(names, r)) for r in rows], default=str))


def _clamp(limit: int) -> int:
    return max(1, min(int(limit), MAX_ROWS))


def _p2_ref(name: str) -> tuple[str, str]:
    """Resolve a model-supplied column name to (sql_expression, output_alias) for the p2 query."""
    if name in A_EXPOSED:
        return f"a.{q(A_EXPOSED[name])}", name
    if name in P2_COLS:
        return f"c.{q(name)}", name
    raise ValueError(
        f"Unknown column {name!r}. Parquet-2 columns: {P2_COLS}. Account columns: {list(A_EXPOSED)}"
    )


def _p2_from(names: list[str]) -> str:
    """Join to a_dim only when at least one referenced column comes from table A."""
    needs_join = any(n in A_EXPOSED for n in names)
    base = "p2 c"
    if needs_join:
        base += f" LEFT JOIN a_dim a ON c.{q(KEY)} = a.{q(KEY)}"
    return base


def _where(filters: dict | None) -> tuple[str, list]:
    clauses, params = [], []
    for col, val in (filters or {}).items():
        expr, _ = _p2_ref(col)
        if isinstance(val, list):
            if not val:
                continue
            clauses.append(f"{expr} IN ({', '.join('?' * len(val))})")
            params.extend(val)
        else:
            clauses.append(f"{expr} = ?")
            params.append(val)
    return (" WHERE " + " AND ".join(clauses)) if clauses else "", params


# ----------------------------------------------------------------------------
# MCP server
# ----------------------------------------------------------------------------
mcp = FastMCP("parquet-data")


@mcp.tool()
def describe_dataset() -> dict:
    """List the columns available in each dataset, and which account columns
    can be added to parquet-2 (disputes) tools."""
    return {
        "key_column": KEY,
        "parquet1_columns": P1_COLS,
        "parquet2_columns": P2_COLS,
        "account_columns_available_for_parquet2_tools": list(A_EXPOSED),
    }


# ---- Parquet 1 tools: p1 only, no joins ------------------------------------
# Your existing parquet-1 tools stay as they are. These two are examples of the pattern.
# Column names (txn_id, amount, ...) are from the sample data: replace with yours.
@mcp.tool()
def get_account_transactions(account_id: str, limit: int = 50) -> list[dict]:
    """Transactions (with account details) for one account. Uses parquet 1 only."""
    return run(
        f"SELECT * FROM p1 WHERE {q(KEY)} = ? ORDER BY txn_date DESC LIMIT {_clamp(limit)}",
        [account_id],
    )


@mcp.tool()
def top_accounts_by_amount(n: int = 10) -> list[dict]:
    """Accounts with the highest total transaction amount. Uses parquet 1 only."""
    return run(
        f"""SELECT {q(KEY)}, any_value(account_name) AS account_name,
                   count(*) AS txn_count, sum(amount) AS total_amount
            FROM p1 GROUP BY {q(KEY)} ORDER BY total_amount DESC LIMIT {_clamp(n)}"""
    )


# ---- Parquet 2 tools: p2, joined to a_dim only when A columns are requested --
@mcp.tool()
def find_disputes(
    filters: dict | None = None,
    columns: list[str] | None = None,
    account_columns: list[str] | None = None,
    limit: int = 50,
) -> list[dict]:
    """Search disputes (parquet 2).

    filters:         {column: value or [values]} equality / IN filters. May use dispute columns
                     or account columns (e.g. {"region": "EMEA", "dispute_status": "open"}).
    columns:         dispute columns to return (default: all).
    account_columns: extra account attributes to add to each row (e.g. ["account_name", "region"]).
                     Call describe_dataset to see what is available.
    """
    cols = columns or P2_COLS
    extra = account_columns or []
    names = list(cols) + list(extra)
    select = ", ".join(f"{e} AS {q(a)}" for e, a in (_p2_ref(n) for n in names))
    where, params = _where(filters)
    # the join decision looks at the select list AND the filters
    from_clause = _p2_from(names + list((filters or {}).keys()))
    return run(f"SELECT {select} FROM {from_clause}{where} LIMIT {_clamp(limit)}", params)


@mcp.tool()
def summarize_disputes(
    group_by: list[str],
    metric: str = "count",
    metric_column: str | None = None,
    filters: dict | None = None,
    limit: int = 100,
) -> list[dict]:
    """Aggregate disputes (parquet 2), grouped by dispute and/or account columns.

    group_by:      columns to group by, e.g. ["region", "reason"].
    metric:        count | sum | avg | min | max
    metric_column: dispute column to aggregate (not needed for count).
    filters:       same as find_disputes.
    """
    if metric not in {"count", "sum", "avg", "min", "max"}:
        raise ValueError("metric must be one of count, sum, avg, min, max")
    if not group_by:
        raise ValueError("group_by needs at least one column")

    groups = [_p2_ref(g) for g in group_by]
    if metric == "count":
        agg = "count(*)"
    else:
        if metric_column not in P2_COLS:
            raise ValueError(f"metric_column must be a parquet-2 column: {P2_COLS}")
        agg = f"{metric}(c.{q(metric_column)})"

    select = ", ".join(f"{e} AS {q(a)}" for e, a in groups)
    group_exprs = ", ".join(e for e, _ in groups)
    where, params = _where(filters)
    from_clause = _p2_from(list(group_by) + list((filters or {}).keys()))
    return run(
        f"SELECT {select}, {agg} AS {q(metric)} FROM {from_clause}{where} "
        f"GROUP BY {group_exprs} ORDER BY {q(metric)} DESC LIMIT {_clamp(limit)}",
        params,
    )


if __name__ == "__main__":
    mcp.run(transport=os.getenv("MCP_TRANSPORT", "stdio"))

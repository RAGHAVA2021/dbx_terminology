"""
MCP server over two parquet files stored in Azure, served from DuckDB.

Data layout
-----------
p1    parquet 1 as-is: (A joined with B). A's columns are repeated on every B row.
p2    parquet 2 as-is: table C (rarely used, many rows per key).
a_dim DISTINCT (key + A columns) taken from p1, so exactly one row per key.
      Built once at startup. It is NOT a copy of the whole 400k-row table.

Rules
-----
* Parquet-1 tools query p1 only. They never touch p2 or a_dim.
* Parquet-2 tools query p2. If (and only if) the question needs A columns,
  the server LEFT JOINs p2 to a_dim on the key. Because a_dim is unique per key,
  the join cannot multiply p2 rows.
* The model never writes SQL. Columns come from allow-lists, values are bound
  as parameters.
* After loading, DuckDB is locked: no file access, no configuration changes.

Config (environment variables)
------------------------------
P1_URI, P2_URI                  az://container/path/file.parquet  (or a local path for testing)
AZURE_STORAGE_CONNECTION_STRING  or  AZURE_STORAGE_ACCOUNT (uses Azure credential chain)
KEY_COLUMN                      join key shared by all tables
A_COLUMNS                       comma-separated columns that belong to table A
MAX_ROWS                        row cap per tool call (default 500)
MCP_TRANSPORT                   stdio (default) | streamable-http
"""
import json
import logging
import math
import os
import sys
from decimal import Decimal

import duckdb

try:  # mcp >= 2.0 renamed FastMCP to MCPServer
    from mcp.server.mcpserver import MCPServer as FastMCP
    from mcp.server.mcpserver.exceptions import ToolError
except ImportError:  # mcp 1.x
    from mcp.server.fastmcp import FastMCP
    from mcp.server.fastmcp.exceptions import ToolError

# stdio transport uses stdout for protocol messages: log to stderr only.
logging.basicConfig(stream=sys.stderr, level=logging.INFO)
log = logging.getLogger("parquet-mcp")


# ----------------------------------------------------------------------------
# Config
# ----------------------------------------------------------------------------
def _require(name: str) -> str:
    value = os.getenv(name)
    if not value:
        sys.exit(f"Missing required environment variable {name}. See the settings table in the guide.")
    return value


P1_URI = _require("P1_URI")
P2_URI = _require("P2_URI")
KEY = os.getenv("KEY_COLUMN", "account_id")
_raw_a = [c.strip() for c in os.getenv("A_COLUMNS", "account_name,region,segment,account_status").split(",") if c.strip()]
if KEY in _raw_a:
    log.warning("A_COLUMNS contains the key column %r; ignoring it (the key is always available).", KEY)
A_COLUMNS = list(dict.fromkeys(c for c in _raw_a if c != KEY))  # no key, no duplicates, order kept
MAX_ROWS = int(os.getenv("MAX_ROWS", "500"))


def q(ident: str) -> str:
    """Quote an identifier. Only ever called on names already validated against an allow-list."""
    return '"' + ident.replace('"', '""') + '"'


def lit(s: str) -> str:
    return "'" + s.replace("'", "''") + "'"


# ----------------------------------------------------------------------------
# Load data
# ----------------------------------------------------------------------------
def _setup_azure(con: duckdb.DuckDBPyConnection) -> None:
    if not any(u.startswith(("az://", "azure://", "abfss://", "abfs://")) for u in (P1_URI, P2_URI)):
        return  # local files, nothing to configure
    con.execute("INSTALL azure; LOAD azure;")
    conn_str = os.getenv("AZURE_STORAGE_CONNECTION_STRING")
    if conn_str:
        con.execute(f"CREATE OR REPLACE SECRET az_secret (TYPE azure, CONNECTION_STRING {lit(conn_str)})")
    else:
        account = _require("AZURE_STORAGE_ACCOUNT")
        con.execute(
            "CREATE OR REPLACE SECRET az_secret "
            f"(TYPE azure, PROVIDER credential_chain, ACCOUNT_NAME {lit(account)})"
        )


def _types(con, table: str) -> dict[str, str]:
    return {r[0]: r[1] for r in con.execute(f"DESCRIBE {table}").fetchall()}


def build_database() -> duckdb.DuckDBPyConnection:
    con = duckdb.connect(os.getenv("DUCKDB_PATH", ":memory:"))
    _setup_azure(con)

    con.execute("CREATE OR REPLACE TABLE p1 AS SELECT * FROM read_parquet(?)", [P1_URI])
    con.execute("CREATE OR REPLACE TABLE p2 AS SELECT * FROM read_parquet(?)", [P2_URI])

    t1, t2 = _types(con, "p1"), _types(con, "p2")
    for name, types in (("p1", t1), ("p2", t2)):
        if KEY not in types:
            raise RuntimeError(f"Key column {KEY!r} not found in {name}: {list(types)}")
    missing = [c for c in A_COLUMNS if c not in t1]
    if missing:
        raise RuntimeError(f"A_COLUMNS not found in parquet 1: {missing}. Parquet 1 has: {list(t1)}")
    clash = [f"a_{c}" for c in A_COLUMNS if c in t2 and f"a_{c}" in t2]
    if clash:
        raise RuntimeError(f"Cannot expose account columns: parquet 2 already has columns named {clash}")
    if not A_COLUMNS:
        log.warning("A_COLUMNS is empty: parquet-2 tools cannot add account details.")

    # One row per key: take the distinct A attributes out of the duplicated parquet 1.
    select_list = ", ".join(q(c) for c in [KEY] + A_COLUMNS)
    con.execute(
        f"CREATE OR REPLACE TABLE a_dim AS SELECT DISTINCT {select_list} FROM p1 WHERE {q(KEY)} IS NOT NULL"
    )

    # Safety check: the join is only fan-out-free if a_dim is really unique per key.
    # If A's attributes differ between rows of the same key, parquet 1 is inconsistent.
    total, uniq = con.execute(f"SELECT count(*), count(DISTINCT {q(KEY)}) FROM a_dim").fetchone()
    if total != uniq:
        bad = con.execute(f"SELECT {q(KEY)} FROM a_dim GROUP BY 1 HAVING count(*) > 1 LIMIT 5").fetchall()
        raise RuntimeError(
            f"a_dim is not unique per {KEY}: {total} rows vs {uniq} keys. "
            f"A_COLUMNS probably contains a column that belongs to table B. Example keys: {[b[0] for b in bad]}"
        )

    # Dry-run the join now, so a key type mismatch fails here with a clear message
    # instead of on the first question. Also measures how many p2 rows have no match.
    try:
        unmatched, rows2, unmatched_keys = con.execute(
            f"""SELECT count(*) FILTER (WHERE a.{q(KEY)} IS NULL), count(*),
                       count(DISTINCT c.{q(KEY)}) FILTER (WHERE a.{q(KEY)} IS NULL)
                FROM p2 c LEFT JOIN a_dim a ON c.{q(KEY)} = a.{q(KEY)}"""
        ).fetchone()
    except duckdb.Error as e:
        raise RuntimeError(
            f"Cannot join p2 to a_dim on {KEY!r}: key types differ (p1: {t1[KEY]}, p2: {t2[KEY]}). "
            f"Cast one side to the same type before loading. Detail: {str(e).splitlines()[0]}"
        ) from e
    if rows2 and unmatched == rows2:
        log.warning("NO p2 rows match parquet 1 on %r. Check key formats (case, spaces, leading zeros).", KEY)
    elif unmatched:
        log.warning("%s of %s p2 rows (%s distinct keys) have no match in parquet 1; "
                    "they stay in results with blank account details.", unmatched, rows2, unmatched_keys)

    n1 = con.execute("SELECT count(*) FROM p1").fetchone()[0]
    log.info("Loaded p1=%s rows, p2=%s rows, a_dim=%s rows", n1, rows2, total)

    # Defence in depth: after loading, the connection can no longer read or write files
    # or change settings, whatever happens in the tool code below.
    con.execute("SET enable_external_access = false")
    con.execute("SET lock_configuration = true")
    return con


CON = build_database()
P1_TYPES = _types(CON, "p1")
P2_TYPES = _types(CON, "p2")
P1_COLS, P2_COLS = list(P1_TYPES), list(P2_TYPES)
# Name a model sees for each A column. If p2 already has a column with that name,
# expose the A version as "a_<name>" so nothing is ambiguous.
A_EXPOSED = {(c if c not in P2_COLS else f"a_{c}"): c for c in A_COLUMNS}
_NUMERIC = ("TINYINT", "SMALLINT", "INTEGER", "BIGINT", "HUGEINT", "UTINYINT", "USMALLINT",
            "UINTEGER", "UBIGINT", "UHUGEINT", "FLOAT", "DOUBLE", "DECIMAL")


# ----------------------------------------------------------------------------
# Helpers
# ----------------------------------------------------------------------------
def _clean(v):
    if isinstance(v, Decimal):
        return float(v)
    if isinstance(v, float) and not math.isfinite(v):
        return None  # NaN / Infinity are not valid JSON
    return v


def run(sql: str, params: list | None = None) -> list[dict]:
    cur = CON.cursor()  # cursor per call, safe with concurrent requests
    try:
        cur.execute(sql, params or [])
        names = [d[0] for d in cur.description]
        rows = cur.fetchall()
    except duckdb.Error as e:
        # ToolError text reaches the model, so it can correct itself. A plain exception would not.
        raise ToolError("Query failed: " + str(e).splitlines()[0]) from e
    out = [{n: _clean(v) for n, v in zip(names, r)} for r in rows]
    return json.loads(json.dumps(out, default=str))  # default=str makes dates JSON-safe


def _clamp(limit) -> int:
    try:
        n = int(limit)
    except (TypeError, ValueError):
        raise ToolError(f"limit must be a whole number, got {limit!r}")
    return max(1, min(n, MAX_ROWS))


def _p2_ref(name: str) -> tuple[str, str]:
    """Resolve a model-supplied column name to (sql_expression, output_alias) for the p2 query."""
    if name in A_EXPOSED:
        return f"a.{q(A_EXPOSED[name])}", name
    if name in P2_COLS:
        return f"c.{q(name)}", name
    raise ToolError(
        f"Unknown column {name!r}. Parquet-2 columns: {P2_COLS}. Account columns: {list(A_EXPOSED)}"
    )


def _p2_from(names: list[str]) -> str:
    """Join to a_dim only when at least one referenced column comes from table A."""
    needs_join = any(n in A_EXPOSED for n in names)
    base = "p2 c"
    if needs_join:
        base += f" LEFT JOIN a_dim a ON c.{q(KEY)} = a.{q(KEY)}"
    return base


_OPS = {"eq": "=", "ne": "<>", "gt": ">", "gte": ">=", "lt": "<", "lte": "<="}


def _scalar(col: str, v):
    if isinstance(v, (str, int, float, bool)):
        return v
    raise ToolError(f"Filter value for {col!r} must be text, a number or true/false, got {v!r}")


def _where(filters: dict | None) -> tuple[str, list]:
    """Filter forms per column:
       "x"                        equals x
       null                       is empty (NULL)
       ["a", "b", null]           is one of these (null allowed in the list)
       {"gte": 1, "lt": 5}        range; operators eq, ne, gt, gte, lt, lte
    """
    clauses, params = [], []
    for col, val in (filters or {}).items():
        expr, _ = _p2_ref(col)
        if val is None:
            clauses.append(f"{expr} IS NULL")
        elif isinstance(val, list):
            if not val:
                raise ToolError(f"Filter for {col!r} is an empty list. Omit the filter or give at least one value.")
            if len(val) > 1000:
                raise ToolError(f"Filter for {col!r} has more than 1000 values.")
            non_null = [_scalar(col, v) for v in val if v is not None]
            parts = []
            if non_null:
                parts.append(f"{expr} IN ({', '.join(['?'] * len(non_null))})")
                params.extend(non_null)
            if len(non_null) != len(val):
                parts.append(f"{expr} IS NULL")
            clauses.append("(" + " OR ".join(parts) + ")")
        elif isinstance(val, dict):
            if not val:
                raise ToolError(f"Filter for {col!r} is an empty object. Use operators: {list(_OPS)}")
            bad = [k for k in val if k not in _OPS]
            if bad:
                raise ToolError(f"Unknown operator(s) {bad} for {col!r}. Use: {list(_OPS)}")
            for op, v in val.items():
                if v is None:
                    raise ToolError(f"Operator {op!r} for {col!r} needs a value. For empty values use null directly.")
                clauses.append(f"{expr} {_OPS[op]} ?")
                params.append(_scalar(col, v))
        else:
            clauses.append(f"{expr} = ?")
            params.append(_scalar(col, val))
    return (" WHERE " + " AND ".join(clauses)) if clauses else "", params


# ----------------------------------------------------------------------------
# MCP server
# ----------------------------------------------------------------------------
mcp = FastMCP("parquet-data")


@mcp.tool()
def describe_dataset() -> dict:
    """List the columns (with types) available in each dataset, and which account columns
    can be added to parquet-2 (disputes) tools."""
    return {
        "key_column": KEY,
        "parquet1_columns": P1_TYPES,
        "parquet2_columns": P2_TYPES,
        "account_columns_available_for_parquet2_tools": {n: P1_TYPES[c] for n, c in A_EXPOSED.items()},
    }


# ---- Parquet 1 tools: p1 only, no joins ------------------------------------
# Your existing parquet-1 tools stay as they are. These two are examples of the pattern.
# Column names (txn_id, amount, ...) are from the sample data: replace with yours.
@mcp.tool()
def get_account_transactions(account_id: str, limit: int = 50) -> list[dict]:
    """Transactions (with account details) for one account. Uses parquet 1 only."""
    return run(
        f"SELECT * FROM p1 WHERE {q(KEY)} = ? ORDER BY txn_date DESC LIMIT {_clamp(limit)}",
        [account_id],
    )


@mcp.tool()
def top_accounts_by_amount(n: int = 10) -> list[dict]:
    """Accounts with the highest total transaction amount. Uses parquet 1 only."""
    return run(
        f"""SELECT {q(KEY)}, any_value(account_name) AS account_name,
                   count(*) AS txn_count, sum(amount) AS total_amount
            FROM p1 GROUP BY {q(KEY)} ORDER BY total_amount DESC LIMIT {_clamp(n)}"""
    )


# ---- Parquet 2 tools: p2, joined to a_dim only when A columns are requested --
@mcp.tool()
def find_disputes(
    filters: dict | None = None,
    columns: list[str] | None = None,
    account_columns: list[str] | None = None,
    order_by: str | None = None,
    descending: bool = False,
    limit: int = 50,
) -> list[dict]:
    """Search disputes (parquet 2).

    filters:         {column: condition} for dispute columns or account columns. A condition is
                     a value (equals), null (is empty), a list (is one of), or a range object
                     with operators eq, ne, gt, gte, lt, lte, e.g.
                     {"region": "EMEA", "reason": ["fraud", "duplicate"],
                      "opened_date": {"gte": "2026-03-01", "lt": "2026-04-01"}}.
    columns:         dispute columns to return (default: all).
    account_columns: extra account attributes to add to each row (e.g. ["account_name", "region"]).
    order_by:        a column to sort by (dispute or account column); descending=true for newest/largest first.
    Call describe_dataset to see the columns and their types.
    """
    cols = columns or P2_COLS
    extra = account_columns or []
    names = list(cols) + list(extra)
    select = ", ".join(f"{e} AS {q(a)}" for e, a in (_p2_ref(n) for n in names))
    where, params = _where(filters)
    order_sql, used = "", list(names) + list((filters or {}).keys())
    if order_by:
        order_expr, _ = _p2_ref(order_by)
        order_sql = f" ORDER BY {order_expr} {'DESC' if descending else 'ASC'}"
        used.append(order_by)
    # the join decision looks at the select list, the filters AND the sort column
    return run(f"SELECT {select} FROM {_p2_from(used)}{where}{order_sql} LIMIT {_clamp(limit)}", params)


@mcp.tool()
def summarize_disputes(
    group_by: list[str],
    metric: str = "count",
    metric_column: str | None = None,
    filters: dict | None = None,
    limit: int = 100,
) -> list[dict]:
    """Aggregate disputes (parquet 2), grouped by dispute and/or account columns.

    group_by:      columns to group by, e.g. ["region", "reason"].
    metric:        count | sum | avg | min | max
    metric_column: dispute column to aggregate (not needed for count; sum and avg need a numeric column).
    filters:       same as find_disputes.
    """
    if metric not in {"count", "sum", "avg", "min", "max"}:
        raise ToolError("metric must be one of count, sum, avg, min, max")
    if not group_by:
        raise ToolError("group_by needs at least one column")

    groups = [_p2_ref(g) for g in group_by]
    if metric == "count":
        agg = "count(*)"
    else:
        if metric_column not in P2_COLS:
            raise ToolError(f"metric_column must be a parquet-2 column: {P2_COLS}")
        if metric in {"sum", "avg"} and not P2_TYPES[metric_column].upper().startswith(_NUMERIC):
            raise ToolError(f"{metric} needs a numeric column; {metric_column!r} is {P2_TYPES[metric_column]}")
        agg = f"{metric}(c.{q(metric_column)})"

    select = ", ".join(f"{e} AS {q(a)}" for e, a in groups)
    group_exprs = ", ".join(e for e, _ in groups)
    where, params = _where(filters)
    from_clause = _p2_from(list(group_by) + list((filters or {}).keys()))
    return run(
        f"SELECT {select}, {agg} AS {q(metric)} FROM {from_clause}{where} "
        f"GROUP BY {group_exprs} ORDER BY {q(metric)} DESC, {group_exprs} LIMIT {_clamp(limit)}",
        params,
    )


if __name__ == "__main__":
    mcp.run(transport=os.getenv("MCP_TRANSPORT", "stdio"))
